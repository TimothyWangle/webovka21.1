from flask import Flask, render_template, request
import sqlite3 as sql

conn = sql.connect('databaze1.db')
conn.execute('CREATE TABLE IF NOT EXISTS students (name TEXT, addr TEXT, city TEXT, pin TEXT)')
conn.close()

app = Flask(__name__, template_folder='templates')


user_reviews = {
    "pepa": "Hele fakt bomba website, ale chybi mi tu vlastne vsechno",
    "franta": "Chtel jsem najit recept na smazeny vajicka, ale dostal jsem se tu. Nevi jak.",
    "alena": "Produkt teto firmy je nejlepsi. Pouzivame ho vsichni. Obcas ho pujcime i dedeckovi."
}

@app.route("/")
@app.route("/home")
@app.route("/index")
def index():
    counter = 1
    return render_template("index.html", reviews=user_reviews, view_count=counter)

@app.route("/review/<username>")
def get_review(username):
    if username in user_reviews:
        return f"Returning requested review. {username}:{user_reviews[username]}"
    else:
        return "Username not found in database."

@app.route("/datasets")
def datasets():
    return render_template("datasets.html")

@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        user_name = request.form.get("username")
        user_review = request.form.get("review")
        user_reviews[user_name] = user_review
    return render_template("contact.html")

@app.route("/student")
def student():
   return render_template("student.html")

@app.route('/list')
def list():
   con = sql.connect("databaze1.db")
   con.row_factory = sql.Row
   
   cur = con.cursor()
   cur.execute("select * from students")
   
   rows = cur.fetchall()
   return render_template("list.html",rows = rows)

@app.route('/addrec',methods = ['POST', 'GET'])
def addrec():
   if request.method == 'POST':
      try:
         nm = request.form['nm']
         addr = request.form['add']
         city = request.form['city']
         pin = request.form['pin']
         
         with sql.connect("database.db") as con:
            cur = con.cursor()
            
            cur.execute("INSERT INTO students (name,addr,city,pin) VALUES (?,?,?,?)",(nm,addr,city,pin) )
            
            con.commit()
            msg = "Record successfully added"
      except:
         con.rollback()
         msg = "error in insert operation"
      
      finally:
         return render_template("result.html",msg = msg)
         con.close()

      

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)